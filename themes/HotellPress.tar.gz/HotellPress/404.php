<?php get_header( 'custom' ); ?>

<div id="content">


	<div id="main-content">


		<div class="page-content default-styles">


            <?php require( 'modules/empty.php' ); ?>


			<br class="clear-fix" />


		</div><!-- .page-content -->


		<br class="clear-fix" />


		<span class="deco-shadow">&nbsp;</span>


	</div><!-- #main-content -->


	<?php require( TEMPLATEPATH . '/modules/social-networks.php' ); ?>


</div><!-- #content -->

<?php get_footer( 'custom' ); ?>
