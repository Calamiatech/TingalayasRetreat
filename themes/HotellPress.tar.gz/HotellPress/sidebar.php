<div id="sidebar">


	<?php if ( ! function_exists( 'dynamic_sidebar' ) || ! dynamic_sidebar( 'defaultsidebararea' ) ) : endif; ?>


</div><!-- #sidebar -->