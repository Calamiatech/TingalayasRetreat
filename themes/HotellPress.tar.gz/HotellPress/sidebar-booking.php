<div class="sidebar">

	<?php #require( TEMPLATEPATH . '/modules/book-online.php' ); ?>

	<div id="call-us" class="box box-center">
	
		<p><em>Or call us!</em><br /> <strong>202-439-7929</strong><br /> Lisa and David Rosenstein</p>
		
	</div><!-- #call-us .box -->

	<div class="box box-center">
	
		<p>Mastercard, Visa, checks<br /> and cash are accepted.</p>
	
		<p><img src="<?php echo bloginfo( 'template_url' ); ?>/media/cards.gif" alt="" /></p>
	
	</div><!-- .box -->

</div><!-- .sidebar -->