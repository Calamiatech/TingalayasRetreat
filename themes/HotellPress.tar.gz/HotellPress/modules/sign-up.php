<div class="sign-up">

	<form action="http://www.aweber.com/scripts/addlead.pl" method="post" name="myform">
	
		<fieldset>

			<input type="hidden" name="meta_web_form_id" value="1741990776" /> 
			
			<input type="hidden" name="meta_split_id" value="" />
			
			<input type="hidden" name="unit" value="lorenzmarketing" />
			
			<input type="hidden" name="redirect" value="http://thelorenzmarketinggroup.com/index_confirmation.html" id="redirect_587a015f579f93f5e48bd41979ea7bf2" />
			
			<input type="hidden" name="meta_redirect_onlist" value="" />
			
			<input type="hidden" name="meta_adtracking" value="" />
			
			<input type="hidden" name="meta_message" value="1" />
			
			<input type="hidden" name="meta_required" value="name,from,custom Phone Number" />
			
			<input type="hidden" name="meta_forward_vars" value="0" />

			<h3>Sign up for a free one-hour consultation ($1000 value)</h3>
			
			<p><label>Name</label> <span class="field-input"><input type="text" name="name" /></span></p>
			
			<p><label>E-mail</label> <span class="field-input"><input type="text" name="from" /></span></p>
			
			<p><label>Phone</label> <span class="field-input"><input type="text" name="custom Phone Number" /></span></p>
			
			<p><label>Industry</label> <span class="field-input"><input type="text" name="custom Industry" /></span></p>
			
			<p class="button"><button type="submit">Destroy my competition!</button></p>
			
		</fieldset>
		
	</form>

</div><!-- .sign-up -->