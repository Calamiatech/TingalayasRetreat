<div class="empty">

	
	<h1><?php _e ( 'Not Found' ); ?></h1>
	
	<p><?php _e (  'Apologies, but no results were found for the requested archive. Perhaps searching will help find a related post.', 'twentyten' ); ?></p>


</div><!-- .empty -->