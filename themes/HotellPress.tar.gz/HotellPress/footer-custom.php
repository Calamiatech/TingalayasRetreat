				<hr />
				
				
				<div id="footer">
	
	
					<?php // wp_nav_menu( array( 'container_class' => 'nav', 'theme_location' => 'footer' ) ); ?>
	<p style="color: #666; ">Copyright &copy; 2012. All rights reserved. | Designed and developed by <a href="http://www.kungfucreatives.com/" style="font-weight: bold; color: #666; text-decoration: none;" target="_blank">Creative Ninjas <img src="http://www.tingalayas.kungfucreatives.com/wp-content/uploads/2012/07/kungfuicon.png" alt="" style="margin: 0 0 0 10px; vertical-align: middle;"></a></p>
	
				</div><!-- #footer -->
				
				
				<span class="deco-page">&nbsp;</span>
	
	
			</div><!-- #container -->


		</div><!-- #bg-top -->
		
		
		<?php wp_footer(); ?>
        

	</body>


</html>