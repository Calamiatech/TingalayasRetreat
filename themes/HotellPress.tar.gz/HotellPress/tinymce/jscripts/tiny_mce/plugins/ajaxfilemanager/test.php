C:\AppServ\www\wordpress\wp-content\themes\hotel\tinymce\jscripts\tiny_mce\plugins\ajaxfilemanager\ajax_preview.php line: 19
../../../../../uploads/kieu3.jpg