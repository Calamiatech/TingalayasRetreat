<div class="search png-fix">


	<form action="<?php echo home_url('/'); ?>" method="get">
	
		<fieldset>
		
			<p>
			
				<input type="text" name="s" value="<?php echo get_search_query (); ?>" />
			
				<button type="submit" class="hiddentext png-fix">Search</button>
					
			</p>
		
		</fieldset>
	
	</form>
	

</div>
<!-- search -->